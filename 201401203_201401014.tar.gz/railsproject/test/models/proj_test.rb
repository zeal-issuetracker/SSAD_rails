require 'test_helper'

class ProjTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
